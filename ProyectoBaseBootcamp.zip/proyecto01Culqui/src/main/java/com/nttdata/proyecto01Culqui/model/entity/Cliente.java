package com.nttdata.proyecto01Culqui.model.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "cliente")
public class Cliente {
    @Id
    private String nombre;
    private String apellido;
    private String dni;
    private String email;
}
