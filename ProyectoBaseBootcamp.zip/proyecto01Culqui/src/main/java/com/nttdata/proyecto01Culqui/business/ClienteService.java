package com.nttdata.proyecto01Culqui.business;

import com.nttdata.proyecto01Culqui.model.ClienteRequest;
import com.nttdata.proyecto01Culqui.model.ClienteResponse;

import java.util.List;

public interface ClienteService {

    public List<ClienteResponse> listarClientes();

    public ClienteResponse registrarClientes(ClienteRequest clienteRequest);
}
