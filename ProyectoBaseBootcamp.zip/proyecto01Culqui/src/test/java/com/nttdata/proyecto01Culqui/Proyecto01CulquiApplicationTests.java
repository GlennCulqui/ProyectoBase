package com.nttdata.proyecto01Culqui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto01CulquiApplicationTests {

	@Test
	void contextLoads() {
	}

}
