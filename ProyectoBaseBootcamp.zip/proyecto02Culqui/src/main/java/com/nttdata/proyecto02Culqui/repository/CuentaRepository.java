package com.nttdata.proyecto02Culqui.repository;

import com.nttdata.proyecto02Culqui.model.entity.Cuenta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CuentaRepository extends JpaRepository<Cuenta, String> {
}
