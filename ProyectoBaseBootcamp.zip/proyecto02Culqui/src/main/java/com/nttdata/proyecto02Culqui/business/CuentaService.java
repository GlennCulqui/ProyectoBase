package com.nttdata.proyecto02Culqui.business;

public interface CuentaService {


}
