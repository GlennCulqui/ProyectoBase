package com.nttdata.proyecto02Culqui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyecto02CulquiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyecto02CulquiApplication.class, args);
	}

}
