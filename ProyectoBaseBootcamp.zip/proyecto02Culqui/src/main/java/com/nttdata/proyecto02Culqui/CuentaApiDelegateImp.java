package com.nttdata.proyecto02Culqui;

import com.nttdata.proyecto02Culqui.business.CuentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CuentaApiDelegateImp implements CuentaApiDelegate{

    @Autowired
    CuentaService cuentaService;

}
