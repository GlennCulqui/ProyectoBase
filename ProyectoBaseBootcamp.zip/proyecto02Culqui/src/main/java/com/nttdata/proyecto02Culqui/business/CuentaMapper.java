package com.nttdata.proyecto02Culqui.business;

import com.nttdata.proyecto02Culqui.model.entity.Cuenta;
import org.springframework.stereotype.Component;

@Component
public class CuentaMapper {

}
