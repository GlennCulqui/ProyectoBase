package com.nttdata.proyecto02Culqui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proyecto02CulquiApplicationTests {

	@Test
	void contextLoads() {
	}

}
